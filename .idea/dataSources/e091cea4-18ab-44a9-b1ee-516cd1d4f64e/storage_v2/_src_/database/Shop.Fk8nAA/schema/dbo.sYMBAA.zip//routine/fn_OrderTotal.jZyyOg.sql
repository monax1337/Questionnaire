--Хранимая процедура для списка клиентов за прошлый месяц
/*CREATE PROCEDURE usp_ClientsLastMonth
AS
SELECT * 
FROM Клиенты
WHERE Код_клиента IN (
  SELECT DISTINCT Код_клиента
  FROM Заказы
  WHERE Дата BETWEEN DATEADD(MONTH, -1, GETDATE()) AND GETDATE()
)*/

--Хранимая процедура для списка товаров по заказу
/*CREATE PROCEDURE usp_OrderItems 
  @OrderId int
AS
SELECT 
  Товар, Количество, Цена, Количество * Цена AS Сумма
FROM 
  ТоварЗаказ JOIN Товары
  ON ТоварЗаказ.Код_товара = Товары.Код_товара
WHERE
  Код_заказа = @OrderId*/

--Хранимая процедура для списка товаров на завтра
/*CREATE PROCEDURE usp_TomorrowOrders
  @Total money OUTPUT  
AS 
BEGIN
    SELECT
        Товары.Товар, ТоварЗаказ.Количество, Товары.Цена, ТоварЗаказ.Количество * Товары.Цена AS Сумма
    FROM
        ТоварЗаказ
    JOIN Товары ON ТоварЗаказ.Код_товара = Товары.Код_товара
    JOIN Заказы ON ТоварЗаказ.Код_заказа = Заказы.Код_заказа
    WHERE
        Заказы.Дата = DATEADD(day, 1, GETDATE());

    SELECT @Total = SUM(Товары.Цена * ТоварЗаказ.Количество)
	FROM ТоварЗаказ
	JOIN Заказы ON ТоварЗаказ.Код_заказа = Заказы.Код_заказа  
	JOIN Товары ON ТоварЗаказ.Код_товара = Товары.Код_товара
	WHERE Заказы.Дата = DATEADD(day, 1, GETDATE())
END*/

--Скалярная функция для суммы заказов на дату
CREATE FUNCTION fn_OrderTotal(@Date date)
RETURNS money
AS
BEGIN
  DECLARE @Total money
  
  SELECT @Total = SUM(Количество * Цена)
  FROM 
    ТоварЗаказ JOIN Товары
    ON ТоварЗаказ.Код_товара = Товары.Код_товара
  JOIN Заказы
    ON ТоварЗаказ.Код_заказа = Заказы.Код_заказа
  WHERE
    Дата = @Date
  
  RETURN @Total
END

go

