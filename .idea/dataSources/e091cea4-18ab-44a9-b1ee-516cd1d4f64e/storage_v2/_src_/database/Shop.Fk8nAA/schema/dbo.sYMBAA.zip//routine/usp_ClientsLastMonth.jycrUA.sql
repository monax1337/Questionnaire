CREATE PROCEDURE usp_ClientsLastMonth
AS
SELECT * 
FROM Клиенты
WHERE Код_клиента IN (
  SELECT DISTINCT Код_клиента
  FROM Заказы
  WHERE Дата BETWEEN DATEADD(MONTH, -1, GETDATE()) AND GETDATE()
)
go

